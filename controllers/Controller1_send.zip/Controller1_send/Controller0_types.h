/*
 * File: Controller0_types.h
 *
 * Real-Time Workshop code generated for Simulink model Controller0.
 *
 * Model version                        : 1.1934
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Feb 02 15:31:04 2012
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Feb 02 15:31:04 2012
 */

#ifndef RTW_HEADER_Controller0_types_h_
#define RTW_HEADER_Controller0_types_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_Controller0_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
