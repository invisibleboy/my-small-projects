/*

A part of the Bound-T test program tp_bro_int.
This is the example program in the Bound-T brochure.

$Id: types.h,v 1.1 2007/06/14 11:04:33 niklas Exp $
*/


#if !defined(TYPES)
#define TYPES

typedef unsigned int uint;

typedef unsigned char uchar;

#include "count_t.h"

#endif
