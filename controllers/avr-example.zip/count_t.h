/*

A part of the Bound-T test program tp_bro_int.
This is the example program in the Bound-T brochure.
This version uses "int" counters.

$Id: count_t.h,v 1.1 2007/06/14 11:04:29 niklas Exp $
*/


#if !defined(COUNT_T)
#define COUNT_T

typedef int count_t;

#endif
